# OGHOST Mesh (prototype)

This is the first control-plane milestone, not a complete VPN yet.

## What works
- A Node.js coordinator accepts outbound WebSocket connections from clients.
- Clients authenticate with a shared enrollment token.
- The coordinator assigns stable-in-session overlay addresses (`10.77.0.x`).
- Clients receive an online peer list and heartbeat status.
- No inbound port is needed on client VPSs.

## Important limitations
- This version does **not** create a Linux network interface, route system traffic,
  or provide transparent private-IP connectivity.
- It does not yet relay TCP/UDP application traffic between peers.
- A real full-mesh VPN needs a data plane (for example, a TUN/userspace network
  stack plus encrypted packet transport). Node.js WebSocket control messages alone
  cannot make `10.77.0.x` work as an OS-level address.
- The coordinator must be reachable over TLS WebSocket at `wss://HOST:443`.
  Put it behind a TLS reverse proxy or use a Node HTTPS server with certificates.
  Port 443 must be permitted by the hosting provider.

## Run coordinator
Requires Node.js 20+.

```bash
npm install
MESH_TOKEN='replace-with-a-long-random-secret' MESH_LISTEN_HOST=127.0.0.1 MESH_LISTEN_PORT=3000 npm run server
```

Expose it as `wss://your-domain:443` through a TLS reverse proxy to
`127.0.0.1:3000`.

## Run a client
On each VPS:

```bash
npm install
MESH_URL='wss://your-domain:443' MESH_TOKEN='the-same-long-random-secret' MESH_NAME='vps-1' npm run client
```

Each client prints its assigned overlay address and currently online peers.

## Security notes
- Use a unique, long random token and keep it private.
- Use TLS (`wss://`) only over the public Internet.
- This prototype has no per-device revocation, persistent database, or key rotation.
  Do not expose it as a production VPN.
