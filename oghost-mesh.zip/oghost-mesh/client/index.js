'use strict';

const WebSocket = require('ws');

const url = process.env.MESH_URL;
const token = process.env.MESH_TOKEN;
const name = process.env.MESH_NAME || `vps-${process.pid}`;

if (!url || !token) {
  console.error('Set MESH_URL=wss://host:443 and MESH_TOKEN.');
  process.exit(1);
}
if (!url.startsWith('wss://')) {
  console.error('Refusing insecure connection. Use wss:// with valid TLS.');
  process.exit(1);
}

let stopped = false;
let ws;
let heartbeat;

function connect() {
  if (stopped) return;
  console.log(`[mesh] connecting to ${url}`);
  ws = new WebSocket(url, { handshakeTimeout: 15000, maxPayload: 16 * 1024 });

  ws.on('open', () => {
    ws.send(JSON.stringify({ type: 'hello', token, name }));
  });

  ws.on('message', raw => {
    let msg;
    try { msg = JSON.parse(raw.toString()); } catch { return; }

    if (msg.type === 'welcome') {
      console.log(`\n[mesh] connected`);
      console.log(`[mesh] device ID: ${msg.id}`);
      console.log(`[mesh] overlay address (directory only): ${msg.ip}`);
      printPeers(msg.peers || []);
      clearInterval(heartbeat);
      heartbeat = setInterval(() => {
        if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify({ type: 'ping' }));
      }, 15000);
    } else if (msg.type === 'peers') {
      printPeers(msg.peers || []);
    } else if (msg.type === 'pong') {
      // heartbeat acknowledged
    }
  });

  ws.on('close', (code, reason) => {
    clearInterval(heartbeat);
    console.log(`[mesh] disconnected (${code} ${reason.toString()}); retrying in 3s`);
    if (!stopped) setTimeout(connect, 3000);
  });
  ws.on('error', err => console.error(`[mesh] ${err.message}`));
}

function printPeers(peers) {
  console.log(`\n[mesh] online peers: ${peers.length}`);
  for (const p of peers) console.log(`  ${p.name.padEnd(20)} ${p.ip}  ${p.id}`);
  if (!peers.length) console.log('  (none)');
  console.log('');
}

process.on('SIGINT', () => {
  stopped = true;
  clearInterval(heartbeat);
  if (ws) ws.close();
  process.exit(0);
});
process.on('SIGTERM', () => {
  stopped = true;
  clearInterval(heartbeat);
  if (ws) ws.close();
  process.exit(0);
});

connect();
