'use strict';

const http = require('node:http');
const crypto = require('node:crypto');
const WebSocket = require('ws');

const TOKEN = process.env.MESH_TOKEN;
if (!TOKEN || TOKEN.length < 24) {
  console.error('Set MESH_TOKEN to a secret of at least 24 characters.');
  process.exit(1);
}

const host = process.env.MESH_LISTEN_HOST || '127.0.0.1';
const port = Number(process.env.MESH_LISTEN_PORT || 3000);
const server = http.createServer((req, res) => {
  if (req.url === '/health') {
    res.writeHead(200, { 'content-type': 'application/json' });
    return res.end(JSON.stringify({ ok: true, service: 'oghost-mesh-control' }));
  }
  res.writeHead(404);
  res.end('Not found');
});

const wss = new WebSocket.Server({ server, maxPayload: 16 * 1024 });
const peers = new Map();
const usedIds = new Set();

function send(ws, obj) {
  if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj));
}
function publicPeers(exceptId) {
  return [...peers.values()]
    .filter(p => p.id !== exceptId && p.ws.readyState === WebSocket.OPEN)
    .map(p => ({ id: p.id, name: p.name, ip: p.ip }));
}
function broadcastPeers() {
  for (const p of peers.values()) {
    send(p.ws, { type: 'peers', peers: publicPeers(p.id) });
  }
}
function allocateIp() {
  // Prototype allocation: 10.77.0.2 through 10.77.0.254.
  for (let n = 2; n <= 254; n++) {
    const ip = `10.77.0.${n}`;
    if (![...peers.values()].some(p => p.ip === ip)) return ip;
  }
  return null;
}

wss.on('connection', (ws) => {
  let registered = false;
  let peerId = null;
  const authTimer = setTimeout(() => {
    if (!registered) ws.close(4001, 'authentication timeout');
  }, 10000);

  ws.on('message', raw => {
    let msg;
    try { msg = JSON.parse(raw.toString()); } catch { return ws.close(4002, 'invalid JSON'); }
    if (!registered) {
      if (msg.type !== 'hello' || typeof msg.token !== 'string' ||
          !crypto.timingSafeEqual(Buffer.from(msg.token.padEnd(TOKEN.length, '\0').slice(0, TOKEN.length)),
                                  Buffer.from(TOKEN)) ||
          msg.token.length !== TOKEN.length) {
        return ws.close(4003, 'authentication failed');
      }
      clearTimeout(authTimer);
      const name = String(msg.name || 'unnamed').replace(/[^a-zA-Z0-9_.-]/g, '').slice(0, 32) || 'unnamed';
      peerId = crypto.randomUUID();
      const ip = allocateIp();
      if (!ip) return ws.close(4004, 'overlay address pool exhausted');
      peers.set(peerId, { id: peerId, name, ip, ws, lastSeen: Date.now() });
      registered = true;
      send(ws, { type: 'welcome', id: peerId, ip, peers: publicPeers(peerId) });
      broadcastPeers();
      console.log(`[+] ${name} ${ip} (${peerId})`);
      return;
    }

    const peer = peers.get(peerId);
    if (!peer) return ws.close(4005, 'session missing');
    if (msg.type === 'ping') {
      peer.lastSeen = Date.now();
      send(ws, { type: 'pong', at: Date.now() });
    } else if (msg.type === 'who') {
      send(ws, { type: 'peers', peers: publicPeers(peerId) });
    }
  });

  ws.on('close', () => {
    clearTimeout(authTimer);
    if (peerId && peers.delete(peerId)) {
      console.log(`[-] disconnected ${peerId}`);
      broadcastPeers();
    }
  });
  ws.on('error', () => {});
});

setInterval(() => {
  const cutoff = Date.now() - 45000;
  for (const p of peers.values()) {
    if (p.lastSeen < cutoff) p.ws.terminate();
  }
}, 15000).unref();

server.listen(port, host, () => {
  console.log(`OGHOST Mesh coordinator listening on ${host}:${port}`);
});
