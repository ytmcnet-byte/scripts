#!/usr/bin/env python3
"""Rotate a Pinggy reverse tunnel and update one Atyro Panel node."""
import json, os, re, sys, time, threading, logging, signal
from pathlib import Path
import requests
import pexpect

BASE = Path(__file__).resolve().parent
CONFIG_FILE = Path(os.environ.get('OGHOST_CONFIG', BASE / 'config.json'))
logging.basicConfig(level=logging.INFO, format='[%(asctime)s] %(levelname)s: %(message)s', datefmt='%H:%M:%S')
LOG = logging.getLogger('pinggy-updater')


def load_config():
    if not CONFIG_FILE.exists():
        raise SystemExit(f'Config missing: {CONFIG_FILE}. Copy config.example.json to config.json and edit it.')
    cfg = json.loads(CONFIG_FILE.read_text())
    required = ['panel_url', 'username', 'password', 'node_name']
    missing = [k for k in required if not str(cfg.get(k, '')).strip()]
    if missing:
        raise SystemExit('Missing config values: ' + ', '.join(missing))
    cfg['panel_url'] = cfg['panel_url'].rstrip('/')
    cfg.setdefault('local_port', 8787)
    cfg.setdefault('pinggy_host', 'ap.free.pinggy.io')
    cfg.setdefault('ssh_port', 443)
    cfg.setdefault('rotation_minutes', 50)
    cfg.setdefault('connect_timeout_seconds', 120)
    cfg.setdefault('retry_seconds', 10)
    cfg.setdefault('verify_tls', True)
    cfg.setdefault('auto_enter_prompts', True)
    return cfg


class Panel:
    def __init__(self, cfg):
        self.cfg = cfg
        self.s = requests.Session()
        self.s.headers.update({'User-Agent': 'OGHOST-Pinggy-Node-Updater/1.0'})
        self.verify = bool(cfg['verify_tls'])

    def login(self):
        url = self.cfg['panel_url']
        self.s.get(url + '/auth/login', timeout=20, verify=self.verify)
        r = self.s.post(url + '/auth/login', data={
            'username': self.cfg['username'], 'password': self.cfg['password']
        }, allow_redirects=True, timeout=25, verify=self.verify)
        # Atyro responds with HTML; the protected nodes API is the definitive session check.
        n = self.s.get(url + '/api/nodes', timeout=25, verify=self.verify)
        if n.status_code != 200:
            raise RuntimeError(f'Panel login/admin check failed: HTTP {n.status_code}. Check panel URL, credentials and admin role.')
        data = n.json()
        if not isinstance(data.get('nodes'), list):
            raise RuntimeError('Unexpected /api/nodes response; expected {"nodes": [...]}')
        return data['nodes']

    def update_node(self, host, port):
        nodes = self.login()
        matches = [n for n in nodes if str(n.get('name', '')).strip().casefold() == self.cfg['node_name'].strip().casefold()]
        if len(matches) != 1:
            names = ', '.join(str(n.get('name')) for n in nodes) or '(none)'
            raise RuntimeError(f'Node name must match exactly one node. Config={self.cfg["node_name"]!r}; panel nodes: {names}')
        n = matches[0]
        ranges = n.get('port_ranges')
        if isinstance(ranges, str):
            ranges = json.loads(ranges or '[]')
        if not isinstance(ranges, list) or not ranges:
            raise RuntimeError('Selected node has no valid port_ranges; refusing to overwrite node config.')
        # Match the full payload expected by Atyro's PATCH /api/nodes/:id handler.
        body = {
            'name': n.get('name') or self.cfg['node_name'],
            'description': n.get('description') or '',
            'location': n.get('location') or '',
            'countryCode': n.get('country_code') or '',
            'ipAddress': host,
            'ipAlias': n.get('ip_alias') or '',
            'daemonPort': int(port),
            'portRanges': ranges,
            'ramMb': int(n['ram_mb']),
            'cpuCores': float(n['cpu_cores']),
            'diskMb': int(n['disk_mb']),
            'enabled': bool(n.get('enabled', 1)),
        }
        r = self.s.patch(f'{self.cfg["panel_url"]}/api/nodes/{int(n["id"])}', json=body, timeout=30, verify=self.verify)
        if not r.ok:
            raise RuntimeError(f'Node update failed: HTTP {r.status_code}: {r.text[:500]}')
        LOG.info('Panel node updated: %s -> %s:%s', n['name'], host, port)


class Tunnel:
    ENDPOINT = re.compile(r'tcp://([a-zA-Z0-9.-]+):([0-9]{1,5})')

    def __init__(self, cfg):
        self.cfg = cfg
        self.child = None
        self.host = None
        self.port = None
        self.reader = None
        self.dead = threading.Event()
        self.stop_reader = threading.Event()

    def start(self):
        args = [
            '-tt', '-p', str(self.cfg['ssh_port']),
            '-o', 'StrictHostKeyChecking=no',
            '-o', 'UserKnownHostsFile=/dev/null',
            '-o', 'ServerAliveInterval=30',
            '-o', 'ServerAliveCountMax=3',
            '-o', 'ExitOnForwardFailure=yes',
            '-R', f'0:127.0.0.1:{int(self.cfg["local_port"])}',
            f'tcp@{self.cfg["pinggy_host"]}'
        ]
        LOG.info('Starting Pinggy tunnel to local port %s ...', self.cfg['local_port'])
        self.child = pexpect.spawn('ssh', args, encoding='utf-8', timeout=1, echo=False)
        deadline = time.time() + int(self.cfg['connect_timeout_seconds'])
        while time.time() < deadline:
            if not self.child.isalive():
                tail = (self.child.before or '')[-700:]
                raise RuntimeError('SSH exited before tunnel was ready. ' + tail)
            try:
                idx = self.child.expect([
                    self.ENDPOINT,
                    r'(?i)(?:password|passphrase)\s*:',
                    r'(?i)(?:press|hit)\s+enter[^\r\n]*',
                    pexpect.EOF,
                    pexpect.TIMEOUT
                ], timeout=1)
                if idx == 0:
                    self.host, self.port = self.child.match.group(1), int(self.child.match.group(2))
                    if not 1 <= self.port <= 65535:
                        raise RuntimeError(f'Pinggy returned invalid port: {self.port}')
                    LOG.info('Pinggy assigned tcp://%s:%s', self.host, self.port)
                    self.reader = threading.Thread(target=self._drain, daemon=True)
                    self.reader.start()
                    return self
                elif idx in (1, 2):
                    if not self.cfg['auto_enter_prompts']:
                        raise RuntimeError('Pinggy/SSH requested input but auto_enter_prompts is disabled.')
                    LOG.info('SSH prompt detected; sending blank Enter as configured.')
                    self.child.sendline('')
                elif idx == 3:
                    raise RuntimeError('SSH closed before returning a tunnel endpoint.')
            except pexpect.TIMEOUT:
                pass
        raise RuntimeError(f'Timed out waiting {self.cfg["connect_timeout_seconds"]}s for Pinggy tcp:// endpoint.')

    def _drain(self):
        while not self.stop_reader.is_set() and self.child and self.child.isalive():
            try:
                chunk = self.child.read_nonblocking(size=2048, timeout=1)
                if chunk:
                    for line in chunk.splitlines():
                        if line.strip(): LOG.info('[ssh] %s', line.strip()[:300])
            except pexpect.TIMEOUT:
                continue
            except (pexpect.EOF, OSError):
                break
        self.dead.set()

    def close(self):
        self.stop_reader.set()
        if self.child and self.child.isalive():
            self.child.sendcontrol('c')
            try: self.child.expect(pexpect.EOF, timeout=4)
            except Exception: self.child.close(force=True)
        self.dead.set()


def main():
    cfg = load_config()
    panel = Panel(cfg)
    active = None
    rotation = max(1, int(cfg['rotation_minutes'])) * 60
    retry = max(3, int(cfg['retry_seconds']))
    LOG.info('Updater started. Node=%s; rotation=%s minutes', cfg['node_name'], cfg['rotation_minutes'])
    while True:
        candidate = None
        try:
            candidate = Tunnel(cfg).start()
            # Change the panel only after the new tunnel has a confirmed endpoint.
            panel.update_node(candidate.host, candidate.port)
            old = active
            active = candidate
            candidate = None
            if old:
                old.close()
            LOG.info('Tunnel active. Next rotation in %s minutes.', cfg['rotation_minutes'])
            end = time.time() + rotation
            while time.time() < end:
                if active.dead.is_set() or not active.child.isalive():
                    raise RuntimeError('Active Pinggy tunnel disconnected unexpectedly.')
                time.sleep(2)
        except KeyboardInterrupt:
            LOG.info('Stopping updater...')
            break
        except Exception as e:
            LOG.error('%s', e)
            if candidate:
                candidate.close()
            # Keep the previous tunnel alive if replacement or panel update failed.
            time.sleep(retry)
    if active:
        active.close()
    LOG.info('Updater stopped.')

if __name__ == '__main__':
    try: main()
    except Exception as exc:
        LOG.error('%s', exc)
        sys.exit(1)
