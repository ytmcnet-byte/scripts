OGHOST / Atyro Panel Pinggy Node Updater

1) Extract this folder on the node VPS (the VPS where the Atyro node agent listens on 127.0.0.1:8787).
2) Make sure ssh and Python 3 are installed.
3) Install Python packages:
   python3 -m pip install --user -r requirements.txt
4) Copy config.example.json to config.json and fill panel_url, admin username/password and the exact node_name.
5) Protect credentials:
   chmod 600 config.json
6) Start:
   python3 tunnel_updater.py

The script starts a new Pinggy reverse TCP tunnel, waits for tcp://host:port,
updates the selected Atyro node using its admin API, and only then closes the old
SSH tunnel. It repeats every 50 minutes. If replacement tunnel or panel update
fails, the old tunnel is kept alive and it retries.

Blank Enter is sent if Pinggy/SSH displays a password/passphrase or press-Enter
prompt. This does not bypass a real password/token challenge; if Pinggy requires
credentials, configure the correct SSH authentication separately.

IMPORTANT:
- Run this on the VPS hosting the node daemon, with daemon listening locally on port 8787.
- The panel account must be an administrator.
- Keep the node's port_ranges configured in the panel; this script preserves them.
- This updates the node IP/daemon port only. It does not change the node agent config.
- A rotating TCP endpoint cannot migrate existing TCP connections; brief reconnects
  may occur when the old tunnel is closed.
- Use a valid HTTPS panel URL. Set verify_tls=false only if you understand the risk.
- Do not share config.json; it contains your panel password.
